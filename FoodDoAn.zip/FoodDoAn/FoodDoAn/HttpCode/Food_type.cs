﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace FoodDoAn.HttpCode
{
    public class Food_type
    {
        private int type_pos, status, id;
        private string img, type_name, username;
        private DateTime tgian;
        private int type;
        private string name;

        public int _id
        {
            get { return this.id; }
            set { this.id = value; }
        }

        public int _type_pos
        {
            get { return this.type_pos; }
            set { this.type_pos = value; }
        }

        public int _status
        {
            get { return this.status; }
            set { this.status = value; }
        }

        public string _img
        {
            get { return this.img; }
            set { this.img = value; }
        }

        public string _type_name
        {
            get { return this.type_name; }
            set { this.type_name = value; }
        }

        public string _username
        {
            get { return this.username; }
            set { this.username = value; }
        }

        public DateTime _tgian
        {
            get { return this.tgian; }
            set { this.tgian = value; }
        }

        public Food_type(int id)
        {
            this._id = id;
        }

        public Food_type(int type_pos, int status, string img, string type_name, string username, DateTime tgian)
        {
            this.type_pos = type_pos;
            this.status = status;
            this.img = img;
            this.type_name = type_name;
            this.username = username;
            this.tgian = tgian;
        }

        public Food_type()
        {

        }

        public bool Add_type()
        {
            string query = "INSERT INTO [dbo].[food_type]([type_name],[type_pos],[type_img],[status],[username],[modidied])VALUES(@name,@type_pos,@img,@status,@username,@modd)";
            SqlParameter[] paras = {
               new SqlParameter("@name", SqlDbType.NVarChar, 50){ Value = this._type_name },
               new SqlParameter("@type_pos", SqlDbType.Int){ Value = this._type_pos},
               new SqlParameter("@img", SqlDbType.NVarChar,255){ Value = this._img},
               new SqlParameter("@status", SqlDbType.Int){ Value = this._status},
               new SqlParameter("@username", SqlDbType.VarChar, 50){ Value = this._username},
               new SqlParameter("@modd", SqlDbType.DateTime){ Value = this._tgian},
                 };
            return DataProvider.executeNonQuery(query, paras);
        }

        public bool Update_type(int id)
        {
            string sQuery = "UPDATE [dbo].[food_type] SET [type_name] =@name ,[type_pos] = @type_pos ,[type_img] = @img ,[status] = @status ,[username] = @username ,[modidied] = @modd  WHERE [type_id] = @id ";
            SqlParameter[] paras = {
               new SqlParameter("@id", SqlDbType.Int){ Value = id },
               new SqlParameter("@name", SqlDbType.NVarChar, 50){ Value = this._type_name },
               new SqlParameter("@type_pos", SqlDbType.Int){ Value = this._type_pos},
               new SqlParameter("@img", SqlDbType.NVarChar,255){ Value = this._img},
               new SqlParameter("@status", SqlDbType.Int){ Value = this._status},
               new SqlParameter("@username", SqlDbType.VarChar, 50){ Value = this._username},
               new SqlParameter("@modd", SqlDbType.DateTime){ Value = this._tgian},
                 };
            return DataProvider.executeNonQuery(sQuery, paras);
        }

        public DataTable dataFood()
        {
            string sQuery = "SELECT * FROM [dbo].[food_type]";
            return DataProvider.getUserName(sQuery);
        }

        public DataTable GetID(int id)
        {
            string sQuery = "SELECT * FROM [dbo].[food_type] WHERE [type_id] = '" + id + "'";
            return DataProvider.getUserName(sQuery);
        }

        public bool delect()
        {
            string sQuery = "DELETE FROM [dbo].[food] WHERE [id] = '" + this._id + "'";
            return DataProvider.deleteUsername(sQuery);
        }
    }
}