﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace FoodDoAn.HttpCode
{
    public class login
    {
        private string username, pass;

        public string _username
        {
            get { return this.username; }
            set { this.username = value; }
        }

        public string _pass
        {
            get { return this.pass; }
            set { this.pass = value; }
        }

        public login(string username,string pass)
        {
            this.username = username;
            this.pass = pass;
        }

        public bool check_login()
        {
            string query = "SELECT * FROM[dbo].[member] WHERE [pass] = @pass and [username] = @username";
            SqlParameter[] paras = 
            {
                new SqlParameter("@username", SqlDbType.NVarChar, 50){ Value = this._username },
                new SqlParameter("@pass", SqlDbType.NVarChar, 255){ Value = this._pass },
            };
            return DataProvider.checkLogin(query, paras);
        }
    }
}