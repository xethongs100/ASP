﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace FoodDoAn.HttpCode
{
    public class _Post
    {
		private int _post_id;
		private string _title;
		private string _short;
		private string _des;
		private string _img;
		private int _status;
		private string _username;
		private DateTime _modified;
		private DateTime _created;

		public DateTime Created
		{
			get { return _created; }
			set { _created = value; }
		}


		public DateTime Modified
		{
			get { return _modified; }
			set { _modified = value; }
		}


		public string UserName
		{
			get { return _username; }
			set { _username = value; }
		}


		public int Status
		{
			get { return _status; }
			set { _status = value; }
		}


		public string Img
		{
			get { return _img; }
			set { _img = value; }
		}


		public string Des
		{
			get { return _des; }
			set { _des = value; }
		}


		public string Short
		{
			get { return _short; }
			set { _short = value; }
		}


		public string Title
		{
			get { return _title; }
			set { _title = value; }
		}


		public int Post_Id
		{
			get { return _post_id; }
			set { _post_id = value; }
		}

        public _Post()
        {

        }

        public _Post(string title,string s_des,string des,DateTime created,DateTime modified,int status,string username,string img)
        {
            this._title = title;
            this._short = s_des;
            this._des = des;
            this._created = created;
            this._modified = modified;
            this._status = status;
            this._username = username;
            this._img = img;
        }

        public bool Add_type()
        {
            string query = "INSERT INTO [dbo].[post]([title],[short_des],[des],[img],[status],[username],[modified],[created]) VALUES(@name,@s_des,@des,@img,@status,@username,@modified,@created)";
            SqlParameter[] paras = {
               new SqlParameter("@name", SqlDbType.NVarChar, 200){ Value = this.Title },
               new SqlParameter("@s_des", SqlDbType.NVarChar, 500){ Value = this.Short },
               new SqlParameter("@des", SqlDbType.NVarChar){ Value = this.Des },
               new SqlParameter("@img", SqlDbType.VarChar, 255){ Value = this.Img },
               new SqlParameter("@status", SqlDbType.Int){ Value = this.Status },
               new SqlParameter("@username", SqlDbType.VarChar, 50){ Value = this.UserName },
               new SqlParameter("@modified", SqlDbType.DateTime){ Value = this.Modified },
               new SqlParameter("@created", SqlDbType.DateTime){ Value = this.Created },
           };
            return DataProvider.executeNonQuery(query, paras);
        }


        public bool Update_type(int id)
        {
            string sQuery = "UPDATE [dbo].[post] SET [title] = @name ,[short_des] =@s_des ,[des] =@des ,[img] =@img ,[status] =@status ,[username] =@username ,[modified] =@modified ,[created] =@created  WHERE [post_id] = @id";
            SqlParameter[] paras = {
               new SqlParameter("@id", SqlDbType.NVarChar, 200){ Value = id },
               new SqlParameter("@name", SqlDbType.NVarChar, 200){ Value = this.Title },
               new SqlParameter("@s_des", SqlDbType.NVarChar, 500){ Value = this.Short },
               new SqlParameter("@des", SqlDbType.NVarChar){ Value = this.Des },
               new SqlParameter("@img", SqlDbType.VarChar, 255){ Value = this.Img },
               new SqlParameter("@status", SqlDbType.Int){ Value = this.Status },
               new SqlParameter("@username", SqlDbType.VarChar, 50){ Value = this.UserName },
               new SqlParameter("@modified", SqlDbType.DateTime){ Value = this.Modified },
               new SqlParameter("@created", SqlDbType.DateTime){ Value = this.Created },
           };
            return DataProvider.executeNonQuery(sQuery, paras);
        }

        public DataTable dataPost()
        {
            string sQuery = "SELECT * FROM [dbo].[post]";
            return DataProvider.getUserName(sQuery);
        }

        public DataTable GetID(int id)
        {
            string sQuery = "SELECT * FROM [dbo].[post] WHERE [post_id] = '" + id + "'";
            return DataProvider.getUserName(sQuery);
        }

        public bool delect(int id)
        {
            string sQuery = "DELETE FROM [dbo].[post] WHERE [post_id] = '" + id + "'";
            return DataProvider.deleteUsername(sQuery);
        }
	}
}