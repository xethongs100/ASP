﻿using FoodDoAn.HttpCode;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FoodDoAn.Admin
{
    public partial class edit_foodtype : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string id = Request.QueryString["id"];
                Food_type ds = new Food_type(Convert.ToInt32(id));

                DataTable dsType = ds.GetID(Convert.ToInt32(id));

                foreach (DataRow row in dsType.Rows)
                {
                    txtName.Text = row["type_name"].ToString();
                    txt_type.Text = row["type_pos"].ToString();
                    Image1.ImageUrl = @"img_type\" + row["type_img"].ToString();
                    txt_status.Text = row["status"].ToString();
                    txt_username.Text = row["username"].ToString();
                    txt_moddified.Text = row["modidied"].ToString();
                };
            }
        }

        protected void btn_update_type_Click(object sender, EventArgs e)
        {
            string path = Server.MapPath("~/Admin/img_type/");
            string img = FileUpload1.FileName;
            if(img=="")
            {
                ClientScript.RegisterStartupScript(this.GetType(), "key", "errorIMG()", true);
                //Response.Redirect("danhsach_sanpham.aspx");
            }
            else
            {
                int id = int.Parse(Request.QueryString["id"]);
                string name = txtName.Text;
                int type_pos = int.Parse(txt_type.Text);
                int status = int.Parse(txt_status.Text);
                string username = txt_username.Text;
                txt_moddified.Text = DateTime.Now.ToString();
                DateTime tgian = DateTime.Parse(txt_moddified.Text);
                FileUpload1.SaveAs(path + img);
                Food_type update = new Food_type(type_pos, status, img, name, username, tgian);
                if (update.Update_type(id))
                {

                    ClientScript.RegisterStartupScript(this.GetType(), "key", "alertSuccess()", true);
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "key", "alertError()", true);
                }
                Response.Redirect("danhsach_typefood.aspx");
            }
        }
    }
}