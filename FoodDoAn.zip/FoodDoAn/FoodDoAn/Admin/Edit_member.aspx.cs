﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace FoodDoAn.Admin
{
    public partial class Edit_member : System.Web.UI.Page
    {
        
        SqlConnection con = new SqlConnection(@"Data Source=DELL\SQLEXPRESS;Initial Catalog=Food_Fresh;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request["username"] != null)
                {
                    string sQuery = "select * from member where username like '%" + Request["username"] + "%'";
                    SqlDataAdapter da = new SqlDataAdapter(sQuery, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    TextBox1.Text = dt.Rows[0]["name"].ToString();
                    TextBox2.Text = dt.Rows[0]["phone"].ToString();
                    ddl_status.SelectedValue = dt.Rows[0]["status"].ToString();
                    ddl_user.SelectedValue = dt.Rows[0]["role"].ToString();
                }
            }
        }

        protected void btn_update_Click(object sender, EventArgs e)
        {
            con.Open();
            string name = TextBox1.Text;
            string phone = TextBox2.Text;
            int role = Convert.ToInt32(ddl_user.SelectedValue);
            int status = Convert.ToInt32(ddl_status.SelectedValue);
            string key = Request["username"];
            string query = "UPDATE member set name='" + name + "',phone='" + phone + "',role=" + role + ",status=" + status+"where username='"+key+"'";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader rd = cmd.ExecuteReader();
            con.Close();
            Response.Redirect("register.aspx");
        }
    }
}