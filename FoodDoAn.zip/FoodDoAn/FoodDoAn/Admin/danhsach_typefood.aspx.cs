﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FoodDoAn.HttpCode;
using System.Web.Script.Serialization;
using System.Data.SqlClient;
using System.Web.Services;
namespace FoodDoAn.Admin
{
    public partial class danhsach_typefood : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["username"] != null)
                {
                    loadData();
                }

                else
                {
                    Response.Redirect("../Login.aspx");
                }
            }
        }

        protected void rptDSTV_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

            PageNumber = Convert.ToInt32(e.CommandArgument) - 1;

            if (e.CommandName == "edit")
            {
                string id = e.CommandArgument.ToString();

                string hash = Server.UrlEncode(id);

                Response.Redirect("~/Admin/edit_foodtype.aspx?id=" + hash);

            }
            if (e.CommandName == "delete")
            {

                string id = e.CommandArgument.ToString();
                Food_type m = new Food_type(Convert.ToInt32(id));
                if (m.delect())
                {
                    Response.Redirect("danhsach_typefood.aspx");
                }
            }

            loadData();
        }

        public void loadData()
        {
            DataTable dt = new DataTable();
            Food_type m = new Food_type();
            dt = m.dataFood();
            PagedDataSource pgitem = new PagedDataSource();
            System.Data.DataView dv = new System.Data.DataView(dt);
            pgitem.DataSource = dv;
            pgitem.AllowPaging = true;
            pgitem.PageSize = 5;
            pgitem.CurrentPageIndex = PageNumber;
            if (pgitem.PageCount > 1)
            {

                rptDSTV.Visible = true;

                if (!pgitem.IsLastPage)
                {

                }
                System.Collections.ArrayList pages = new System.Collections.ArrayList();
                for (int i = 0; i <= pgitem.PageCount - 1; i++)
                {
                    pages.Add((i + 1).ToString());
                    rptDSTV.DataSource = pages;
                    rptDSTV.DataBind();
                }

            }
            else
            {
                rptDSTV.Visible = false;
            }
            Repeater1.DataSource = pgitem;
            Repeater1.DataBind();
        }

        public int PageNumber
        {
            get
            {
                if (ViewState["PageNumber"] != null)
                    return Convert.ToInt32(ViewState["PageNumber"]);
                else
                    return 0;
            }
            set
            {
                ViewState["PageNumber"] = value;
            }
        }

        protected void LinpkNext_Click(object sender, EventArgs e)
        {
            PageNumber += 1;
            Repeater1.DataBind();
        }

        [WebMethod]
        public static string searchCode(string key, string page)
        {
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            Dictionary<string, object> json = new Dictionary<string, object>();

            SqlConnection conn = new SqlConnection(@"Data Source=DELL\SQLEXPRESS;Initial Catalog=food_fresh;Integrated Security=True");
            conn.Open();
            //string sQuery = "SELECT * FROM [food]";

            if (key != null && key.Length > 0)
            {
                string sQuery = " SELECT * FROM [food_type] WHERE (([type_name] LIKE '%' + @TenSP + '%') OR ([type_pos] LIKE '%' + @GiaSP + '%')) ";
                SqlCommand cmd = new SqlCommand(sQuery, conn);
                SqlParameter[] sparam =
                {
                    new SqlParameter("@TenSP",key),
                    new SqlParameter("@GiaSP",key)
                };
                cmd.Parameters.AddRange(sparam);
                cmd.CommandText = sQuery;

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataTable dt = new DataTable();
                da.Fill(dt);
                conn.Close();

                int limit = 5;
                int soTrang = dt.Rows.Count / limit + (dt.Rows.Count % limit == 0 ? 0 : 1);
                int page1 = (page == null) ? 1 : Convert.ToInt32(page);
                int from = (page1 - 1) * limit;
                int to = (page1 * limit) - 1;

                for (int i = dt.Rows.Count - 1; i >= 0; i--)
                {
                    // i < from ----- to < i
                    if (i < from || to < i)
                    {
                        dt.Rows.RemoveAt(i);
                    }
                }

                foreach (DataRow dr in dt.Rows)
                {
                    row = new Dictionary<string, object>();
                    foreach (DataColumn col in dt.Columns)
                    {
                        row.Add(col.ColumnName, dr[col]);
                    }
                    rows.Add(row);
                }

                string[] result = new string[soTrang];
                for (int i = 0; i < soTrang; i++)
                {
                    result[i] = i.ToString();
                }

                json.Add("json", rows);
                json.Add("record", result);
            }
            return new JavaScriptSerializer().Serialize(json);
        }
    }
}