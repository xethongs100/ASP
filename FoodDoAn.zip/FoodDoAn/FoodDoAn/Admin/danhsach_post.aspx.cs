﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FoodDoAn.HttpCode;
namespace FoodDoAn.Admin
{
    public partial class danhsach_post : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["username"] != null)
                {
                    _Post post = new _Post();
                    Repeater1.DataSource = post.dataPost();
                    Repeater1.DataBind();
                }

                else
                {
                    Response.Redirect("../Login.aspx");
                }
            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "edit")
            {
                string id = e.CommandArgument.ToString();

                string hash = Server.UrlEncode(id);

                Response.Redirect("~/Admin/edit_post.aspx?id=" + hash);

            }
            if (e.CommandName == "delete")
            {

                string id = e.CommandArgument.ToString();
                int post_id = int.Parse(Server.UrlEncode(id));
                _Post post = new _Post();

                if (post.delect(Convert.ToInt32(post_id)))
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "key", "delete()", true);
                    Response.Redirect("danhsach_post.aspx");
                }
            }
        }
    }
}