﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FoodDoAn.HttpCode;
namespace FoodDoAn.Admin
{
    public partial class food_type : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txt_moddified.Text = DateTime.Now.ToString();
            txt_moddified.Enabled = false;
        }

        protected void btn_add_type_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            int type = int.Parse(txt_type.Text);
            string path = Server.MapPath("~/Admin/img_type/");
            string img = FileUpload1.FileName;
            int status = int.Parse(txt_status.Text);
            string username = txt_username.Text;
            DateTime tgian = DateTime.Parse(txt_moddified.Text);
            FileUpload1.SaveAs(path + img);

            Food_type add = new Food_type(type, status, img, name, username, tgian);

            if(add.Add_type())
            {
                ClientScript.RegisterStartupScript(this.GetType(), "randomkey", "alertSuccess()", true);
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "randomkey", "alertError()", true);
            }
        }
    }
}