﻿$(document).ready(function ($) {

    $('#btn_timkiem').click(function (e) {
        alert(123);
        e.preventDefault();
    });

});