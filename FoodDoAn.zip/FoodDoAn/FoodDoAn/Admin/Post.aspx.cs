﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FoodDoAn.HttpCode;
namespace FoodDoAn.Admin
{
    public partial class Post : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_add_post_Click(object sender, EventArgs e)
        {
            string path = Server.MapPath("~/Admin/img_post/");
            string img = FileUpload1.FileName;
            if(img=="")
            {
                ClientScript.RegisterStartupScript(this.GetType(), "randomkey", "ErrorIMG()", true);
            }
            else
            {
                string title = txt_title.Text;
                string s_des = txt_short_des.Text;
                string des = txt_des.Text;
                DateTime created = DateTime.Now;
                DateTime modified = DateTime.Now;
                int status = int.Parse(txt_status.Text);
                string username = txt_username.Text;
                FileUpload1.SaveAs(path+img);

                _Post post = new _Post(title,s_des,des,created,modified,status,username,img);

                if(post.Add_type())
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "randomkey", "alertSuccess()", true);
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "randomkey", "alertError()", true);
                }
            }
        }
    }
}