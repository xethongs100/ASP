﻿using FoodDoAn.HttpCode;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FoodDoAn.Admin
{
    public partial class edit_post : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                string id = Request.QueryString["id"];
                _Post ds = new _Post();
                DataTable dsType = ds.GetID(Convert.ToInt32(id));

                foreach (DataRow row in dsType.Rows)
                {
                    txt_title.Text = row["title"].ToString();
                    txt_short_des.Text = row["short_des"].ToString();
                    txt_des.Text = row["des"].ToString();
                    Image1.ImageUrl = @"img_post\" + row["img"].ToString();
                    txt_status.Text = row["status"].ToString();
                    txt_username.Text = row["username"].ToString();
                };
            }
        }

        protected void btn_update_post_Click(object sender, EventArgs e)
        {
            string path = Server.MapPath("~/Admin/img_post/");
            string img = FileUpload1.FileName;
            if (img == "")
            {
                ClientScript.RegisterStartupScript(this.GetType(), "randomkey", "ErrorIMG()", true);
            }
            else
            {
                int id = int.Parse(Request.QueryString["id"]);
                string title = txt_title.Text;
                string s_des = txt_short_des.Text;
                string des = txt_des.Text;
                DateTime created = DateTime.Now;
                DateTime modified = DateTime.Now;
                int status = int.Parse(txt_status.Text);
                string username = txt_username.Text;
                FileUpload1.SaveAs(path + img);

                _Post post = new _Post(title, s_des, des, created, modified, status, username, img);

                if (post.Update_type(id))
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "randomkey", "alertSuccess()", true);
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "randomkey", "alertError()", true);
                }
            }
        }
    }
}