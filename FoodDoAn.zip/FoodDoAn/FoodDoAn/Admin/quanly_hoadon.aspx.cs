﻿using FoodDoAn.HttpCode;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FoodDoAn.Admin
{
    public partial class quanly_hoadon : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["username"] != null)
                {
                    loadData();
                }

                else
                {
                    Response.Redirect("../Login.aspx");
                }
            }
        }

        protected void rptDSTV_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

            PageNumber = Convert.ToInt32(e.CommandArgument) - 1;
            loadData();
        }
        public void loadData()
        {
            DataTable dt = new DataTable();
            Food m = new Food();
            dt = m.Bill();
            PagedDataSource pgitem = new PagedDataSource();
            System.Data.DataView dv = new System.Data.DataView(dt);
            pgitem.DataSource = dv;
            pgitem.AllowPaging = true;
            pgitem.PageSize = 5;
            pgitem.CurrentPageIndex = PageNumber;
            if (pgitem.PageCount > 1)
            {

                rptDSTV.Visible = true;

                if (!pgitem.IsLastPage)
                {
                    //LinkNext.NavigateUrl = 
                }
                System.Collections.ArrayList pages = new System.Collections.ArrayList();
                for (int i = 0; i <= pgitem.PageCount - 1; i++)
                {
                    pages.Add((i + 1).ToString());
                    rptDSTV.DataSource = pages;
                    rptDSTV.DataBind();
                }

            }
            else
            {
                rptDSTV.Visible = false;
            }
            rptPages.DataSource = pgitem;
            rptPages.DataBind();
        }
        public int PageNumber
        {
            get
            {
                if (ViewState["PageNumber"] != null)
                    return Convert.ToInt32(ViewState["PageNumber"]);
                else
                    return 0;
            }
            set
            {
                ViewState["PageNumber"] = value;
            }
        }
    }
}