﻿using FoodDoAn.HttpCode;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Script.Serialization;
using System.Web.Services;
namespace FoodDoAn
{
    public partial class register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                if (Session["username"] != null)
                {
                    SqlConnection con = new SqlConnection(@"Data Source=DELL\SQLEXPRESS;Initial Catalog=food_fresh;Integrated Security=True");
                    string sQuery = "";
                    if (Request["username"] != null)
                    {
                        Response.Redirect("Edit_member.aspx?username=" + Request["username"]);
                    }

                    if (Request["xoa_username"] != null)
                    {
                        con.Open();
                        sQuery = "delete from member where username like'%" + Request["xoa_username"] + "%'";
                        SqlCommand cmd = new SqlCommand(sQuery, con);
                        SqlDataReader rd = cmd.ExecuteReader();
                        con.Close();
                        Response.Redirect("register.aspx");
                    }
                    else
                    {
                        sQuery = "select * from member";
                        SqlDataAdapter da = new SqlDataAdapter(sQuery, con);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        Repeater1.DataSource = dt;
                        Repeater1.DataBind();
                    }
                }

                else
                {
                    Response.Redirect("../Login.aspx");
                }
            }
        }

        protected void btn_register_Click(object sender, EventArgs e)
        {
            //string firstName = txtFirstName.Text;
            string name = txtName.Text;
            string username = txtUserName.Text;
            //string email = txtEmail.Text;
            string phone = txtPhone.Text;
            string pass = txtPassword.Text;
            int role = Convert.ToInt32(ddl_user.SelectedValue);
            int status = Convert.ToInt32(ddl_status.SelectedValue);
            //string status = ddl_status.SelectedValue;
            Member member = new Member(username, pass, name, phone, role,status);
            if (member.addMember())
            {

                ClientScript.RegisterStartupScript(this.GetType(), "randomkey", "alertSuccess()", true);
            }
            else if (member.checkUser(username))
            {

                ClientScript.RegisterStartupScript(this.GetType(), "randomkey", "alertError()", true);
            }
            else
            {

                ClientScript.RegisterStartupScript(this.GetType(), "randomkey", "alertError()", true);
            }
            Response.Redirect("Admin/register.aspx");
        }

        [WebMethod]
        public static string searchCode(string key, string page)
        {
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            Dictionary<string, object> json = new Dictionary<string, object>();

            SqlConnection conn = new SqlConnection(@"Data Source=DELL\SQLEXPRESS;Initial Catalog=food_fresh;Integrated Security=True");
            conn.Open();
            //string sQuery = "SELECT * FROM [food]";

            if (key != null && key.Length > 0)
            {
                string sQuery = " SELECT * FROM [member] WHERE ([username] LIKE '%' + @TenSP + '%') OR ([name] LIKE '%' + @GiaSP + '%') ";
                SqlCommand cmd = new SqlCommand(sQuery, conn);
                SqlParameter[] sparam =
                {
                    new SqlParameter("@TenSP",key),
                    new SqlParameter("@GiaSP",key)
                };
                cmd.Parameters.AddRange(sparam);
                cmd.CommandText = sQuery;

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataTable dt = new DataTable();
                da.Fill(dt);
                conn.Close();

                int limit = 5;
                int soTrang = dt.Rows.Count / limit + (dt.Rows.Count % limit == 0 ? 0 : 1);
                int page1 = (page == null) ? 1 : Convert.ToInt32(page);
                int from = (page1 - 1) * limit;
                int to = (page1 * limit) - 1;

                for (int i = dt.Rows.Count - 1; i >= 0; i--)
                {
                    // i < from ----- to < i
                    if (i < from || to < i)
                    {
                        dt.Rows.RemoveAt(i);
                    }
                }

                foreach (DataRow dr in dt.Rows)
                {
                    row = new Dictionary<string, object>();
                    foreach (DataColumn col in dt.Columns)
                    {
                        row.Add(col.ColumnName, dr[col]);
                    }
                    rows.Add(row);
                }

                string[] result = new string[soTrang];
                for (int i = 0; i < soTrang; i++)
                {
                    result[i] = i.ToString();
                }

                json.Add("json", rows);
                json.Add("record", result);
            }
            return new JavaScriptSerializer().Serialize(json);
        }
    }
}