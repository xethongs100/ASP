﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FoodDoAn
{
    public partial class admin : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                if (Session["username"] != null)
                {
                    lb_username.Text = "Hello Admin  " + Session["username"].ToString();
                }
                else
                {
                    lb_username.Text = "";
                }
            }


        }

        protected void btn_logout_Click(object sender, EventArgs e)
        {
            Session["username"] = null;
            Response.Redirect("../Login.aspx");
        }
    }
}