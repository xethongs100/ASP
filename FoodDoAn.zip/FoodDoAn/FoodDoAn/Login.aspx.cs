﻿using FoodDoAn.HttpCode;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FoodDoAn
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_dangnhap_Click(object sender, EventArgs e)
        {
            string username = txt_username.Text;
            string password = txt_pass.Text;

            if (username == "" || password == "")
            {
                ClientScript.RegisterStartupScript(this.GetType(), "key", "Error()", true);
            }
            else
            {
                string pass = StringProc.MD5Hash(password);
                login login = new login(username, pass);
                if (login.check_login())
                {
                    Session["username"] = username;
                    Response.Redirect("Admin/index.aspx");
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "key", "Fail()", true);
                }
            }
        }


    }
}