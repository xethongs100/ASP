﻿using FoodDoAn.HttpCode;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FoodDoAn.Home
{
    public partial class detail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Request["detail"]!=null)
            {
                Food detail = new Food();
                DataTable dt = detail.getDetail(int.Parse(Request["detail"].ToString()));
                int id_type = 0;
                foreach (DataRow row in dt.Rows)
                {
                    id_type = int.Parse(row["type"].ToString());
                }
                DataTable dr = detail.getProduct(id_type);
                Repeater1.DataSource = dt;
                Repeater1.DataBind();

                Repeater2.DataSource = dr;
                Repeater2.DataBind();
                
            }
        }
    }
}