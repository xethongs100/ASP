﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FoodDoAn.Home
{
    public partial class checkout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                if (Session["cart"] != null && Session["thanhtien"] != null)
                {
                    Repeater1.DataSource = Session["cart"];
                    Repeater1.DataBind();
                    lbl_total.Text = Session["thanhtien"].ToString() + "VND";
                }
            }
        }

        protected void btn_checkout_Click(object sender, EventArgs e)
        {
            if (Session["cart"] != null && Session["thanhtien"] != null && Session["soluong"] != null)
            {
                string name = txt_name.Text;
                string phone = txt_phone.Text;
                string address = txt_address.Text;
                string moddified = DateTime.Now.ToString();
                string created = DateTime.Now.ToString();
                int qty = int.Parse(Session["soluong"].ToString());
                int sum = int.Parse(Session["thanhtien"].ToString());
                int status = 0;
                string username = "xethong1";

                SqlParameter[] sParas = 
                {
                    new SqlParameter("@cus_name", SqlDbType.NVarChar, 100){ Value = name },
                    new SqlParameter("@phone", SqlDbType.VarChar, 50){ Value = phone },
                    new SqlParameter("@address", SqlDbType.NVarChar, 255){ Value = address },
                    new SqlParameter("@quan", SqlDbType.Int){ Value = qty },
                    new SqlParameter("@sum", SqlDbType.Int){ Value = sum },
                    new SqlParameter("@status", SqlDbType.Int){ Value = status },
                    new SqlParameter("@username", SqlDbType.VarChar, 50){ Value = username },
                    new SqlParameter("@modified", SqlDbType.VarChar, 255){ Value = moddified },
                    new SqlParameter("@created", SqlDbType.VarChar, 255){ Value = created }

                };

                //    new SqlParameter[9];
                //sParas[0] = new SqlParameter("@name", name);
                //sParas[1] = new SqlParameter("@phone", phone);
                //sParas[2] = new SqlParameter("@address", address);
                //sParas[3] = new SqlParameter("@quan", qty);
                //sParas[4] = new SqlParameter("@sum", sum);
                //sParas[5] = new SqlParameter("@status", status);
                //sParas[6] = new SqlParameter("@username", username);
                //sParas[7] = new SqlParameter("@modified", moddified);
                //sParas[8] = new SqlParameter("@created", created);

                DataTable dt = new DataTable();
                dt = (DataTable)Session["cart"];
                SqlConnection conn = new SqlConnection(@"Data Source=DELL\SQLEXPRESS;Initial Catalog=food_fresh;Integrated Security=True");
                conn.Open();
                string sQuery = "INSERT INTO [dbo].[order]([cus_name],[cus_phone],[cus_add],[quan],[sum],[status],[username],[modified],[created]) VALUES(@cus_name,@phone,@address,@quan,@sum,@status,@username,@modified,@created)";
                SqlCommand cmd = new SqlCommand(sQuery, conn);
                cmd.Parameters.AddRange(sParas);
                cmd.ExecuteNonQuery();
                sQuery = "select @@identity";
                cmd = new SqlCommand(sQuery, conn);
                int id = Convert.ToInt32(cmd.ExecuteScalar().ToString());
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    sQuery = "INSERT INTO [dbo].[order_detail]([order_id],[food_id],[quan],[unit],[price],[total]) VALUES(@order_id,@food_id,@qty,@unit,@price,@total)";

                    SqlParameter[] paras = 
                    {
                        new SqlParameter("@order_id", SqlDbType.Int){ Value = id },
                        new SqlParameter("@food_id", SqlDbType.Int){ Value =  int.Parse(dt.Rows[i]["STT"].ToString())},
                        new SqlParameter("@qty", SqlDbType.Int){ Value =  int.Parse(dt.Rows[i]["Quality"].ToString())},
                        new SqlParameter("@unit", SqlDbType.NVarChar,50){ Value =  dt.Rows[i]["Unit"].ToString()},
                        new SqlParameter("@price", SqlDbType.Float){ Value = float.Parse(dt.Rows[i]["GiaSP"].ToString())},
                        new SqlParameter("@total", SqlDbType.Float){ Value = float.Parse(dt.Rows[i]["Total"].ToString())},

                    };
                    //SqlParameter[] paras = new SqlParameter[6];
                    //paras[0] = new SqlParameter("@order_id", id);
                    //paras[1] = new SqlParameter("@food_id", dt.Rows[i]["STT"]);
                    //paras[2] = new SqlParameter("@qty", dt.Rows[i]["Quality"]);
                    //paras[3] = new SqlParameter("@unit", dt.Rows[i]["Unit"]);
                    //paras[4] = new SqlParameter("@price", dt.Rows[i]["GiaSP"]);
                    //paras[4] = new SqlParameter("@total", dt.Rows[i]["Total"]);
                    cmd = new SqlCommand(sQuery, conn);
                    cmd.Parameters.AddRange(paras);
                    cmd.ExecuteNonQuery();
                }
                conn.Close();
                Session["cart"] = null;
                Response.Write("<script> alert('Đặt hàng thành công') </script>");
            }
            Response.Redirect("index.aspx");
        }
    }
}