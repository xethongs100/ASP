﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FoodDoAn.Home
{
    public partial class Cart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                if (Session["cart"] != null && Session["thanhtien"] != null && Session["soluong"]!=null)
                {
                    Repeater1.DataSource = Session["cart"];
                    Repeater1.DataBind();
                    lbl_thanhtien.Text = Session["thanhtien"].ToString() + " VND";
                }

                if(Request["xoa_cart"]!=null)
                {
                    int total = 0;
                    int countQTY = 0;
                    //Response.Write("abc");

                    DataTable dt = (DataTable)Session["cart"];

                    foreach(DataRow row in dt.Rows)
                    {
                        if(Request["xoa_cart"].ToString()==row["STT"].ToString())
                        {
                            dt.Rows.Remove(row);
                            break;
                        }
                    }

                    foreach (DataRow row in dt.Rows)
                    {
                        total += int.Parse(row["Total"].ToString());
                        
                    }

                    Session["thanhtien"] = total;
                    Session["cart"] = dt;

                    Response.Redirect("Cart.aspx");
                }

                if(Request["checkout"]!=null)
                {
                    Response.Redirect("checkout.aspx");
                }
            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            
        }
    }
}