﻿using FoodDoAn.HttpCode;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FoodDoAn.Home
{
    public partial class index : System.Web.UI.Page
    {
        private int total = 0;
        private int countQTY = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                if(Request["detail"]!=null)
                {
                    Response.Redirect("detail.aspx?detail=" + Request["detail"].ToString());
                }
                Food slider = new Food();
                DataTable dt = slider.Slider();
                Repeater2.DataSource = dt;
                Repeater2.DataBind();
                loadData();
            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "add_cart")
            {
                HiddenField hf_stt = (HiddenField)e.Item.FindControl("STT");
                HiddenField hf_tensp = (HiddenField)e.Item.FindControl("TenSP");
                HiddenField hf_giasp = (HiddenField)e.Item.FindControl("GiaSP");
                HiddenField hf_hinhanh = (HiddenField)e.Item.FindControl("HinhAnh");
                HiddenField hf_unit = (HiddenField)e.Item.FindControl("Unit");
                DataTable dt = new DataTable();
                
                if (Session["cart"] == null)
                {
                    dt.Columns.Add("STT");
                    dt.Columns.Add("TenSP");
                    dt.Columns.Add("GiaSP");
                    dt.Columns.Add("HinhAnh");
                    dt.Columns.Add("Quality");
                    dt.Columns.Add("Unit");
                    dt.Columns.Add("Total");
                    dt.Columns.Add("ThanhTien");
                }
                else
                {
                    dt = (DataTable)Session["cart"];

                }
                int iRow = checkExist(dt, hf_stt.Value);
                if (iRow != -1)
                {
                    dt.Rows[iRow]["Quality"] = Convert.ToInt32(dt.Rows[iRow]["Quality"]) + 1;
                    dt.Rows[iRow]["Total"] = Convert.ToInt32(dt.Rows[iRow]["Quality"]) * Convert.ToInt32(dt.Rows[iRow]["GiaSP"]);
                    dt.Rows[iRow]["ThanhTien"] = 0 + Convert.ToInt32(dt.Rows[iRow]["Total"]);
                }
                else
                {
                    DataRow dr = dt.NewRow();
                    dr["STT"] = hf_stt.Value;
                    dr["TenSP"] = hf_tensp.Value;
                    dr["GiaSP"] = hf_giasp.Value;
                    dr["HinhAnh"] = hf_hinhanh.Value;
                    dr["Quality"] = 1;
                    dr["Unit"] = hf_unit.Value;
                    dr["Total"] = hf_giasp.Value;

                    dr["ThanhTien"] = hf_giasp.Value;

                    dt.Rows.Add(dr);
                }
                foreach(DataRow row in dt.Rows)
                {
                    total += int.Parse(row["Total"].ToString());
                    countQTY += 1;
                }
                Session["soluong"] = countQTY;
                Session["thanhtien"] = total;
                Session["cart"] = dt;
            }
        }

        private int checkExist(DataTable dt, string stt)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i]["STT"].ToString() == stt)
                {
                    return i;
                }
            }
            return -1;
        }

        protected void rptDSTV_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

            PageNumber = Convert.ToInt32(e.CommandArgument) - 1;
            loadData();
        }

        public void loadData()
        {
            DataTable dt = new DataTable();
            Food m = new Food();
            dt = m.dataFood();
            PagedDataSource pgitem = new PagedDataSource();
            System.Data.DataView dv = new System.Data.DataView(dt);
            pgitem.DataSource = dv;
            pgitem.AllowPaging = true;
            pgitem.PageSize = 8;
            pgitem.CurrentPageIndex = PageNumber;
            if (pgitem.PageCount > 1)
            {

                rptDSTV.Visible = true;

                if (!pgitem.IsLastPage)
                {
                    //LinkNext.NavigateUrl = 
                }
                System.Collections.ArrayList pages = new System.Collections.ArrayList();
                for (int i = 0; i <= pgitem.PageCount - 1; i++)
                {
                    pages.Add((i + 1).ToString());
                    rptDSTV.DataSource = pages;
                    rptDSTV.DataBind();
                }

            }
            else
            {
                rptDSTV.Visible = false;
            }
            Repeater1.DataSource = pgitem;
            Repeater1.DataBind();
        }


        public int PageNumber
        {
            get
            {
                if (ViewState["PageNumber"] != null)
                    return Convert.ToInt32(ViewState["PageNumber"]);
                else
                    return 0;
            }
            set
            {
                ViewState["PageNumber"] = value;
            }
        }
    }
}